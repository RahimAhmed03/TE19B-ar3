﻿using System.ComponentModel;
using System.Collections.Generic;
using System;

namespace Biluthyrning
{
    // Kostnad för bilarna
    // Volvo ABC123 -> 500:- /d
    // Saab DEF456 -> 400:- /d
    // Fiat GHI789 -> 199:- /d
    // Extra km = 2:- /km
    // Array? 
    // [
    //      ["ABC123", "500"],
    //      ["DEF456", "400"],
    //      ["GHI789", "199"]
    // ]


    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Välkommen till Biluthyrningen!");
            Console.WriteLine("Ange kundens personnr: ");
            Console.WriteLine("Ange bilens regnr: ");
            Console.WriteLine("Ange antal km: ");
            Console.WriteLine("Ange antal dygn: ");
        }
    }

    class Avtal
    {
        public DateTime Datum { get; set; }
        public string RegNr { get; set; }

        public int Km { get; set; }
        public int Kostnad { get; set; }
        public int Tidsram { get; set; }
        public string Personnr { get; set; }

        private IDictionary<string, int> _bilar = new IDictionary<string, int>();

        Avtal() 
        {
            _bilar.Add("ABC123", 500);
            _bilar.Add("DEF456", 400);
            _bilar.Add("GHI789", 199);
        }

    }
}
